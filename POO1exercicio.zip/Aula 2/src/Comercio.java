public class Comercio {

	public Vendedor criaVendedor() {
		Vendedor v = new Vendedor();
		return v;
	}

	public void addvendas(Vendedor vendedor, Venda venda, int i) {
		vendedor.vendas[i] = venda;
	}

	public double calculaComissao(Vendedor vendedor) {
		double comissao = 0;
		
		for(int i = 0; i < vendedor.vendas.length; i++) {
			if(vendedor.vendas[i] != null) {
				if(vendedor.vendas[i].valor >= 2000) {
					comissao = vendedor.vendas[i].valor*0.10;
				}
			}
		}
		return comissao;	
	}

}
