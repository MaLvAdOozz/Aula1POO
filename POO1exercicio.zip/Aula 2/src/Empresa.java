
public class Empresa {
		public String nome;
}
