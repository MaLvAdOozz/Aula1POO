
public class Main {

	public static void main(String[] args) {
		Venda venda1 = new Venda();
		venda1.mes = 10;
		venda1.valor = 3500;
		
		Comercio comercio = new Comercio();
		Empresa empresa = new Empresa();
		
		Vendedor coiote = comercio.criaVendedor();
		//Vendedor v = new Vendedor();
		
		coiote.empresa = empresa;
		
		comercio.addvendas(coiote, venda1, 0);
		
		System.out.println(venda1.mes);
		System.out.println(venda1.valor);	

	}

}
