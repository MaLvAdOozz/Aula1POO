public class Venda {
	public int mes;
	public double valor;
}
