
public class Vendedor {
	public Venda[] vendas = new Venda[10];
	public Empresa empresa;
	
}
